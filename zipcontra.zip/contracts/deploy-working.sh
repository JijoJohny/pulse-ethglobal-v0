#!/bin/bash
# Working deployment script with simplified contracts

# Load environment variables
source .env

# Rootstock Testnet RPC
RPC_URL="https://public-node.testnet.rsk.co"

echo "🚀 Deploying CLMSR Protocol (Simplified) to Rootstock Testnet"
echo "============================================================="

echo "📝 Using simplified contracts that avoid OpenZeppelin import issues"

# Deploy MockRBTC
echo "🪙 Deploying MockRBTC..."
MOCK_RBTC=$(forge create --rpc-url $RPC_URL \
  --private-key $CONTRACT_DEPLOYER_PRIVATE_KEY \
  contracts/mocks/MockRBTC.sol:MockRBTC \
  --constructor-args "Rootstock Bitcoin" "RBTC" 18 1000000000000000000000000 \
  --json | jq -r '.deployedTo')

echo "✅ MockRBTC deployed at: $MOCK_RBTC"

# Deploy CLMSRPositionSimple
echo "🎨 Deploying CLMSRPositionSimple..."
POSITION=$(forge create --rpc-url $RPC_URL \
  --private-key $CONTRACT_DEPLOYER_PRIVATE_KEY \
  contracts/CLMSRPositionSimple.sol:CLMSRPositionSimple \
  --constructor-args "0x0000000000000000000000000000000000000000" "CLMSR Position NFT" "CLMSR-POS" "https://api.pulse08.com/metadata/" \
  --json | jq -r '.deployedTo')

echo "✅ CLMSRPositionSimple deployed at: $POSITION"

# Deploy CLMSRMarketCoreSimple
echo "🏪 Deploying CLMSRMarketCoreSimple..."
MARKET_CORE=$(forge create --rpc-url $RPC_URL \
  --private-key $CONTRACT_DEPLOYER_PRIVATE_KEY \
  contracts/CLMSRMarketCoreSimple.sol:CLMSRMarketCoreSimple \
  --constructor-args $MOCK_RBTC $POSITION \
  --json | jq -r '.deployedTo')

echo "✅ CLMSRMarketCoreSimple deployed at: $MARKET_CORE"

echo ""
echo "🔗 Linking contracts..."
echo "Note: You need to grant MARKET_CORE_ROLE to the market core contract"
echo "Call: grantRole(MARKET_CORE_ROLE, $MARKET_CORE) on the Position contract"

echo ""
echo "🎉 Deployment completed!"
echo "========================"
echo "MockRBTC:              $MOCK_RBTC"
echo "CLMSRPositionSimple:   $POSITION"  
echo "CLMSRMarketCoreSimple: $MARKET_CORE"
echo ""
echo "🔗 View on Explorer:"
echo "https://explorer.testnet.rsk.co/address/$MARKET_CORE"
